# ONGEKI Link 文件与 TLS 工具说明

## 可直接附在下载页的简短文案

> ONGEKI Link 安装包包含联机插件和 TLS 加密连接辅助程序。游戏自带的旧 Mono 对 TLS 兼容性不足，辅助程序使用 Windows 的 TLS 能力连接中继服务器并校验服务器证书。程序由插件自动在后台启动，无需手动打开。请完整保留 DLL、EXE 及 EXE.config 三个文件，并另外安装本人机台的专属联机配置。

## 文件位置

```text
BepInEx/
├─ plugins/
│  └─ OngekiLink/
│     ├─ OngekiLink.dll
│     ├─ OngekiLink.TlsProxy.exe
│     └─ OngekiLink.TlsProxy.exe.config
└─ config/
   └─ cn.amall.ongekilink.cfg     ← 本人机台专属，单独领取
```

- `OngekiLink.dll`：BepInEx 插件，连接游戏原有机间联机逻辑，完成机台准入、虚拟连接及游戏内信息显示。
- `OngekiLink.TlsProxy.exe`：Windows .NET Framework 4.8 辅助程序，为旧游戏运行环境提供已验证的 TLS 1.2 加密连接。
- `OngekiLink.TlsProxy.exe.config`：指定辅助程序使用的 .NET 运行环境。它不是机台接入配置，不要用本人的 Node/Token 替换其内容。
- `cn.amall.ongekilink.cfg`：本人的接入配置，包含专属节点与 Token，不应转发给其他机台或放入公开下载包。

辅助程序与插件版本号可以不同：TLS 工具当前沿用已验证的0.1.2，插件已有后续版本。插件更新包仅含DLL时，应保留原来的两个TLS文件。

## 它如何工作

```text
游戏中的联机插件
    ↓ 本机 127.0.0.1 随机端口（单连接、一次性随机凭证验证）
Windows TLS 辅助程序
    ↓ TLS 1.2 加密连接与服务器证书校验
本服 ONGEKI Link 中继
```

插件自动启动隐藏窗口的辅助进程。辅助程序只接受本机的一条已验证连接，再连接指定 Link 中继；本机监听不对外网开放。它转发 Link 协议字节，不处理主站账号登录或成绩保存业务。

正常关闭游戏或 Link 会话结束后，连接和辅助进程会清理。使用者无需单独运行EXE、设置系统代理或开放一个本机公网监听端口。

当前默认配置使用`TLS=true`、`UseWindowsTlsProxy=true`，所以正式支持的安装方式需要完整分发这两个TLS文件；不以关闭TLS或证书校验作为安装步骤。无需为使用本工具而更新游戏内置Mono或BepInEx。

## 基础包与专属配置

通用基础包包含三份程序文件和本文说明，不包含真实Node、Token、KEYCHIP、账号或Aime资料，也不包含游戏资源与第三方Mod。基础包适用于已经正确安装受支持BepInEx环境的机台，不替代游戏运行环境安装。

本阶段玩家自助领取配置尚未接入主站。只复制通用文件，不会自动取得联机权限：没有专属配置时插件默认为关闭，保留原生局域网行为。已有测试机无需重新安装基础包，继续使用各自已验证的专属配置。

后续玩家领取流程应为：登录主站ALL.NET → 选择本人有效ONGEKI机台 → 领取专属配置 → 将cfg放入对应config目录 → 游戏通过本服认证 → Link准入与自动分房。

## 常见排查

- 运行环境：辅助程序目标为Windows .NET Framework 4.8。
- EXE缺失或无法启动：检查上述目录是否完整、文件是否被移动或拦截。
- TLS连接失败：检查系统时间、网络和中继证书；不要关闭证书校验。
- 游戏能正常访问本服但Link未连接：检查Link中继连接、本机专属配置和机台权限；游戏服务器与Link中继是不同的连接。
- 需要提交日志时，不要发送包含Token的配置全文。可提供错误文字和BepInEx日志中的非敏感连接状态。
